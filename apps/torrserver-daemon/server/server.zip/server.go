package server

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"reflect"
	"sync"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"

	"server/log"
	"server/settings"
	"server/torr"
	"server/torr/state"
)

var (
	upgrader = websocket.Upgrader{
		CheckOrigin: func(r *http.Request) bool {
			return true 
		},
	}
	clients   = make(map[*websocket.Conn]bool)
	clientsMu sync.Mutex
)

func Broadcast(status []*state.TorrentStatus) {
    clientsMu.Lock()
    defer clientsMu.Unlock()

    if len(clients) == 0 {
        return
    }

    message := gin.H{"type": "stats-update", "payload": gin.H{"torrents": status}}
    for client := range clients {
        if err := client.WriteJSON(message); err != nil {
            log.TLogln("ws write error:", err)
            client.Close()
            delete(clients, client)
        }
    }
}

func handleWebSocket(c *gin.Context) {
	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.TLogln("ws upgrade error:", err)
		return
	}
	defer conn.Close()

	clientsMu.Lock()
	clients[conn] = true
	clientsMu.Unlock()
	log.TLogln("WebSocket client connected")

	var statusList []*state.TorrentStatus
	for _, t := range torr.ListTorrent() {
		statusList = append(statusList, t.Status())
	}
	if len(statusList) > 0 {
		conn.WriteJSON(gin.H{"type": "stats-update", "payload": gin.H{"torrents": statusList}})
	}


	for {
		if _, _, err := conn.ReadMessage(); err != nil {
			clientsMu.Lock()
			delete(clients, conn)
			clientsMu.Unlock()
			log.TLogln("WebSocket client disconnected")
			break
		}
	}
}

func Run() {
	    go func() {
        ticker := time.NewTicker(500 * time.Millisecond)
        defer ticker.Stop()

        var lastStats []*state.TorrentStatus

        for range ticker.C {
            // 1) gather current statuses
            var current []*state.TorrentStatus
            for _, t := range torr.ListTorrent() {
                current = append(current, t.Status())
            }

            // 2) compare deep-equal to last snapshot
            if !reflect.DeepEqual(current, lastStats) {
                Broadcast(current)

                // 3) store a copy for next comparison
                lastStats = make([]*state.TorrentStatus, len(current))
                copy(lastStats, current)
            }
        }
    }()



	gin.SetMode(gin.ReleaseMode)
	router := gin.New()
	router.Use(gin.Recovery())
	router.Use(func(c *gin.Context) {
		start := time.Now()
		c.Next()
		latency := time.Since(start)
		log.TLogln(fmt.Sprintf("| %3d | %13v | %-7s | %s",
			c.Writer.Status(),
			latency,
			c.Request.Method,
			c.Request.URL.Path,
		))
	})

	router.POST("/torrents", torr.Torrents)
	router.GET("/stream/:hash/:id", torr.Stream)
	router.HEAD("/stream/:hash/:id", torr.Stream)
	router.GET("/ws", handleWebSocket)

	router.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	router.GET("/", func(c *gin.Context) {
		c.String(http.StatusOK, "TorrServer Daemon: Core API is running")
	})

	port := settings.Get().Port
	log.TLogln(fmt.Sprintf("Starting daemon API server on port %d", port))

	srv := &http.Server{
		Addr:    fmt.Sprintf(":%d", port),
		Handler: router,
	}

	go func() {
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.TLogln(fmt.Sprintf("Listen error: %s\n", err))
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.TLogln("Shutdown signal received, closing daemon...")
	torr.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		log.TLogln(fmt.Sprintf("Server Shutdown error: %s", err))
	}

	log.TLogln("Server exiting.")
}